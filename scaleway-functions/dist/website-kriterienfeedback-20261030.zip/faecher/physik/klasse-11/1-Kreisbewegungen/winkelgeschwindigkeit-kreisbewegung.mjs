import { setupPhysicsStepTabs } from "./components/physics-step-tabs.mjs";
import { createPhysicsTaskProgress } from "./components/physics-task-progress.mjs?v=20260930a";
import { setupPhysicsSemanticTask } from "./components/physics-semantic-task.mjs?v=20261029-criteria-v1";
import { enableTokenDrag, wasDragged } from "./components/token-drag.mjs";
import { appendPhysicsText, createIndexedSymbol, physicsTextSpan } from "./components/physics-notation.mjs?v=20261022-force-indices";
import { angleAtCycleElapsed, angleAtElapsed, angularSpeed, circleVectors, clamp, elapsedInCycle, frequencyFromPeriod, sectorPath, shuffleIncorrect, tangentialSpeed } from "./components/circle-kinematics.mjs";

function unlockSolution(event, expectedCode, downloadLinkId, messageId) {
  event.preventDefault();
  const form = event.currentTarget;
  const enteredCode = form.elements["solution-code"].value.toUpperCase().replace(/[^A-Z0-9]/g, "");
  const normalizedExpectedCode = expectedCode.replace(/[^A-Z0-9]/g, "");
  const downloadLink = document.getElementById(downloadLinkId);
  const message = document.getElementById(messageId);

  if (enteredCode === normalizedExpectedCode) {
    downloadLink.hidden = false;
    message.className = "solution-code-message";
    message.textContent = "Code korrekt. Das Sicherungsblatt ist freigeschaltet.";
    return;
  }

  downloadLink.hidden = true;
  message.className = "solution-code-message error";
  message.textContent = "Der eingegebene Code ist nicht gültig.";
}

window.unlockSolution = unlockSolution;

const SCRIPT_SERVER_URL ="https://unterrichtkiichezbn4-ki-auswertung.functions.fnc.fr-par.scw.cloud/";
const taskProgress = createPhysicsTaskProgress("aufgabe3");

function setFeedback(target, status, message) {
  const element = typeof target === "string" ? document.getElementById(target) : target;
  element.hidden = false;
  element.className = `physics-feedback ${status}`;
  element.replaceChildren();
  appendPhysicsText(element, message);
}

function renderFormulaSymbol(target, value) {
  target.replaceChildren();
  if (value === "vB") {
    target.append(createIndexedSymbol("v", "B"));
    target.setAttribute("aria-label", "v mit Index B");
  } else {
    target.textContent = value;
  }
}

function bindKeyboardButton(button, handler) {
  button.addEventListener("click", handler);
  button.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    handler();
  });
}

function formatNumber(value, digits = 2) {
  return Number(value).toFixed(digits).replace(".", ",");
}

function formatElapsed(value) {
  return formatNumber(Math.floor((value + Number.EPSILON) * 10) / 10, 1);
}

function formatRadians(value) {
  const known = [[Math.PI / 6, "π/6"], [Math.PI / 4, "π/4"], [Math.PI / 3, "π/3"], [Math.PI / 2, "π/2"], [Math.PI * 2 / 3, "2π/3"], [Math.PI, "π"], [Math.PI * 1.5, "3π/2"], [Math.PI * 5 / 3, "5π/3"], [Math.PI * 2, "2π"]];
  return known.find(([number]) => Math.abs(number - value) < 0.000001)?.[1] || formatNumber(value);
}

function setupAngleSimulation() {
  const host = document.querySelector('[data-circle-simulation="angle"]');
  const inputs = { phi: host.querySelector('[data-angle-input="phi"]'), time: host.querySelector('[data-angle-input="time"]') };
  const arc = host.querySelector("[data-angle-arc]");
  const radius = host.querySelector("[data-angle-radius]");
  const body = host.querySelector("[data-angle-body]");
  const label = host.querySelector("[data-angle-label]");
  const panel = host.closest("[data-physics-panel]");
  const status = host.querySelector("[data-angle-status]");
  const HOLD_SECONDS = 1;
  const RUNNING_MESSAGE = "Bewegung läuft und startet nach jedem Durchlauf neu.";
  const reducedMotion = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let elapsedSeconds = 0;
  let holdSeconds = 0;
  let running = false;
  let userPaused = false;
  let frame = 0;
  let last = 0;

  function update() {
    const phi = Number(inputs.phi.value);
    const time = Number(inputs.time.value);
    const currentAngle = angleAtElapsed(phi, time, elapsedSeconds);
    const frame = circleVectors(currentAngle - Math.PI / 2, 112);
    const bodyPoint = { x: 190 + frame.position.x, y: 165 + frame.position.y };
    body.setAttribute("cx", bodyPoint.x); body.setAttribute("cy", bodyPoint.y);
    radius.setAttribute("x2", bodyPoint.x); radius.setAttribute("y2", bodyPoint.y);
    arc.setAttribute("d", sectorPath(190, 165, 52, currentAngle));
    const labelFrame = circleVectors(currentAngle / 2 - Math.PI / 2, 75);
    const labelPoint = { x: 190 + labelFrame.position.x, y: 165 + labelFrame.position.y };
    label.setAttribute("x", labelPoint.x); label.setAttribute("y", labelPoint.y); label.textContent = "Δφ";
    host.querySelector("[data-angle-phi]").textContent = formatRadians(phi);
    host.querySelector("[data-angle-time]").textContent = formatNumber(time, 1);
    host.querySelector("[data-angle-omega]").textContent = formatNumber(angularSpeed(phi, time));
  }
  // Nach jedem Durchlauf bleibt der überstrichene Winkel kurz stehen, dann beginnt die Bewegung von vorn.
  function tick(time) {
    if (!running) return;
    const elapsed = last ? (time - last) / 1000 : 0; last = time;
    const duration = Number(inputs.time.value);
    if (elapsedSeconds >= duration) {
      holdSeconds += elapsed;
      if (holdSeconds >= HOLD_SECONDS) { elapsedSeconds = 0; holdSeconds = 0; }
    } else {
      elapsedSeconds = Math.min(duration, elapsedSeconds + elapsed);
    }
    update();
    frame = requestAnimationFrame(tick);
  }
  function run() { if (running || userPaused || reducedMotion() || panel.hidden || document.hidden) return; running = true; last = 0; frame = requestAnimationFrame(tick); }
  function stop() { running = false; cancelAnimationFrame(frame); }
  function showStatic() { elapsedSeconds = Number(inputs.time.value); holdSeconds = 0; update(); status.textContent = "Bewegung ohne Animation vollständig angezeigt."; }
  function restart() {
    userPaused = false; stop(); elapsedSeconds = 0; holdSeconds = 0;
    if (reducedMotion()) { showStatic(); return; }
    update(); status.textContent = RUNNING_MESSAGE; run();
  }
  function pause() { userPaused = true; stop(); status.textContent = "Wiederholung pausiert. „Neustarten“ startet die Bewegung mit den aktuellen Werten."; }
  host.querySelector('[data-angle-action="restart"]').addEventListener("click", restart);
  host.querySelector('[data-angle-action="pause"]').addEventListener("click", pause);
  Object.values(inputs).forEach((input) => input.addEventListener("input", () => {
    if (reducedMotion()) { showStatic(); return; }
    elapsedSeconds = 0; holdSeconds = 0; update();
    status.textContent = userPaused ? "Werte geändert. „Neustarten“ startet die Bewegung mit den neuen Werten." : "Werte geändert. Die Bewegung läuft mit den neuen Werten weiter.";
  }));
  document.addEventListener("visibilitychange", () => { if (document.hidden) stop(); else run(); });
  new MutationObserver(() => { if (panel.hidden) stop(); else run(); }).observe(panel, { attributes: true, attributeFilter: ["hidden"] });
  if (reducedMotion()) showStatic(); else { update(); run(); }
}

function setupSpeedSimulation() {
  const host = document.querySelector('[data-circle-simulation="speed"]');
  const inputs = { radius: host.querySelector('[data-speed-input="radius"]'), omega: host.querySelector('[data-speed-input="omega"]') };
  const panel = host.closest("[data-physics-panel]"); const status = host.querySelector("[data-speed-status]");
  let rotation = -Math.PI / 2; let running = false; let frame = 0; let last = 0;
  function update() {
    const radiusMeters = Number(inputs.radius.value); const omega = Number(inputs.omega.value); const radius = radiusMeters * 30;
    const vectors = circleVectors(rotation, radius);
    const point = { x: 220 + vectors.position.x, y: 220 + vectors.position.y };
    const vectorLength = Math.min(95, 26 + omega * radiusMeters * 11);
    const tangent = { x: point.x + vectors.tangent.x * vectorLength, y: point.y + vectors.tangent.y * vectorLength };
    host.querySelector("[data-speed-orbit]").setAttribute("r", radius);
    const radial = host.querySelector("[data-speed-radius]"); radial.setAttribute("x2", point.x); radial.setAttribute("y2", point.y);
    const body = host.querySelector("[data-speed-body]"); body.setAttribute("cx", point.x); body.setAttribute("cy", point.y);
    const vector = host.querySelector("[data-speed-vector]"); vector.setAttribute("x1", point.x); vector.setAttribute("y1", point.y); vector.setAttribute("x2", tangent.x); vector.setAttribute("y2", tangent.y);
    const vectorLabel = host.querySelector("[data-speed-vector-label]");
    const labelPoint = {
      x: clamp(tangent.x - vectors.inward.x * 42, 30, 410),
      y: clamp(tangent.y - vectors.inward.y * 42, 20, 420),
    };
    vectorLabel.setAttribute("transform", `translate(${labelPoint.x} ${labelPoint.y})`);
    host.querySelector("[data-speed-radius-value]").textContent = formatNumber(radiusMeters, 1);
    host.querySelector("[data-speed-omega-value]").textContent = formatNumber(omega, 1);
    host.querySelector("[data-speed-v-value]").textContent = formatNumber(tangentialSpeed(omega, radiusMeters), 1);
  }
  function tick(time) { if (!running) return; const elapsed = last ? time - last : 0; last = time; rotation += elapsed * 0.001 * Number(inputs.omega.value); update(); frame = requestAnimationFrame(tick); }
  function start() { if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { update(); status.textContent = "Bewegung ist wegen der Einstellung für reduzierte Bewegung angehalten."; return; } if (!running) { running = true; last = 0; status.textContent = "Bewegung läuft im Uhrzeigersinn."; frame = requestAnimationFrame(tick); } }
  function pause(message = "Bewegung pausiert.") { running = false; cancelAnimationFrame(frame); status.textContent = message; }
  host.querySelector('[data-speed-action="start"]').addEventListener("click", start);
  host.querySelector('[data-speed-action="pause"]').addEventListener("click", () => pause());
  host.querySelector('[data-speed-action="reset"]').addEventListener("click", () => { pause("Bewegung zurückgesetzt."); rotation = -Math.PI / 2; update(); });
  Object.values(inputs).forEach((input) => input.addEventListener("input", update));
  document.addEventListener("visibilitychange", () => { if (document.hidden && running) pause("Bewegung pausiert, weil die Seite nicht sichtbar ist."); });
  new MutationObserver(() => { if (panel.hidden && running) pause("Bewegung pausiert, weil der Reiter gewechselt wurde."); }).observe(panel, { attributes: true, attributeFilter: ["hidden"] });
  update();
}

function setupFormulaBuilder({ id, expected, equation, rememberId }) {
  const target = document.getElementById(id); let selected = "";
  let values = shuffleIncorrect(expected, expected);
  const slots = expected.map((_, index) => ({ index, value: "" }));
  // Zeichen per Pointer-Drag ablegen, zwischen Feldern tauschen oder zurück
  // in den Speicher ziehen. Antippen bleibt als Alternative ohne Ziehen.
  const dragTargets = { dropSelector: `#${id} .formula-slot`, bankSelector: `#${id} .formula-token-bank` };
  const place = (value, from, to) => {
    if (from >= 0) slots[from].value = "";
    if (to >= 0) {
      const previous = slots[to].value;
      slots[to].value = value;
      if (from >= 0 && previous) slots[from].value = previous;
    }
    selected = "";
    document.getElementById(rememberId).hidden = true;
    render();
    taskProgress.save();
  };
  const render = () => {
    target.replaceChildren();
    const bank = document.createElement("div"); bank.className = "formula-token-bank"; bank.setAttribute("aria-label", "Formelzeichen");
    values.forEach((value) => { const token = document.createElement("button"); token.type = "button"; token.className = "cloze-token"; renderFormulaSymbol(token, value); token.disabled = slots.some((slot) => slot.value === value); token.classList.toggle("is-picked", selected === value); enableTokenDrag(token, { ...dragTargets, getLabel: () => value, renderGhost: (ghost) => renderFormulaSymbol(ghost, value), onDrop: (slot) => { if (slot) place(value, -1, Number(slot.dataset.index)); else render(); } }); bindKeyboardButton(token, () => { if (wasDragged(token)) return; selected = selected === value ? "" : value; render(); }); bank.append(token); });
    const line = document.createElement("div"); line.className = "formula-line"; line.setAttribute("aria-label", equation);
    const isQuotient = id !== "formula-speed";
    const slotRoles = isQuotient ? ["", ", Zähler", ", Nenner"] : ["", "", ""];
    const buttons = slots.map((slot, index) => { const button = document.createElement("button"); button.type = "button"; button.className = "formula-slot"; button.dataset.value = slot.value; button.dataset.index = String(index); button.classList.toggle("is-filled", Boolean(slot.value)); button.classList.toggle("is-selected", Boolean(selected) && !slot.value); if (slot.value) renderFormulaSymbol(button, slot.value); else button.textContent = "?"; button.setAttribute("aria-label", slot.value === "vB" ? `Feld ${index + 1}: v mit Index B${slotRoles[index]}` : `Feld ${index + 1} der Formel${slotRoles[index]}${slot.value ? `: ${slot.value}` : ": leer"}`); enableTokenDrag(button, { ...dragTargets, getLabel: () => slots[index].value, renderGhost: (ghost) => renderFormulaSymbol(ghost, slots[index].value), onDrop: (dropSlot, onBank) => { const value = slots[index].value; const to = dropSlot ? Number(dropSlot.dataset.index) : -1; if (to >= 0 && to !== index) place(value, index, to); else if (onBank) place(value, index, -1); else render(); } }); bindKeyboardButton(button, () => { if (wasDragged(button)) return; if (selected) place(selected, -1, index); else if (slots[index].value) place(slots[index].value, index, -1); }); return button; });
    line.append(buttons[0], document.createTextNode(" = "));
    if (isQuotient) { const fraction = document.createElement("div"); fraction.className = "formula-fraction"; const bar = document.createElement("span"); bar.className = "formula-fraction__bar"; bar.setAttribute("aria-hidden", "true"); fraction.append(buttons[1], bar, buttons[2]); line.append(fraction); }
    else line.append(buttons[1], document.createTextNode(" · "), buttons[2]);
    const actions = document.createElement("div"); actions.className = "cloze-actions";
    const check = document.createElement("button"); check.type = "button"; check.className = "physics-primary-button"; check.textContent = "Formel prüfen";
    const reset = document.createElement("button"); reset.type = "button"; reset.className = "secondary-action"; reset.textContent = "Formel zurücksetzen";
    const feedback = document.createElement("div"); feedback.className = "physics-feedback"; feedback.hidden = true; feedback.setAttribute("role", "status"); feedback.setAttribute("aria-live", "polite");
    check.addEventListener("click", () => { const correct = slots.filter((slot, index) => slot.value === expected[index]).length; if (correct === expected.length) { setFeedback(feedback, "success", "Korrekt: Die Formel ist richtig zusammengesetzt."); document.getElementById(rememberId).hidden = false; } else { document.getElementById(rememberId).hidden = true; if (correct) setFeedback(feedback, "partial", `${correct} von ${expected.length} Zeichen stehen richtig. Prüfe die noch leeren oder vertauschten Felder.`); else setFeedback(feedback, "error", "Noch nicht korrekt. Überlege, welche Größe auf der linken Seite stehen muss."); } });
    reset.addEventListener("click", () => { slots.forEach((slot) => { slot.value = ""; }); selected = ""; values = shuffleIncorrect(expected, expected); document.getElementById(rememberId).hidden = true; render(); });
    actions.append(check, reset);
    target.append(bank, line, actions, feedback);
  };
  taskProgress.registerPart(id, () => ({ slots: slots.map((slot) => slot.value), bankOrder: [...values] }), (saved) => {
    const allowed = new Set(expected);
    if (!saved || !Array.isArray(saved.slots) || saved.slots.length !== slots.length
      || saved.slots.some((value) => value !== "" && !allowed.has(value))) return;
    const filled = saved.slots.filter(Boolean);
    if (new Set(filled).size !== filled.length || !Array.isArray(saved.bankOrder)
      || saved.bankOrder.length !== values.length || saved.bankOrder.some((value) => !allowed.has(value))
      || new Set(saved.bankOrder).size !== values.length) return;
    saved.slots.forEach((value, index) => { slots[index].value = value; });
    values = [...saved.bankOrder];
    selected = "";
    render();
  });
  render();
}

function setupFrequency() {
  const input = document.getElementById("period-input");
  const panel = input.closest("[data-physics-panel]");
  const body = panel.querySelector("[data-frequency-body]");
  const radius = panel.querySelector("[data-frequency-radius]");
  const status = panel.querySelector("[data-frequency-status]");
  let elapsedSeconds = 0;
  let running = false;
  let frame = 0;
  let last = 0;

  function update() {
    const period = Number(input.value);
    const currentElapsed = elapsedInCycle(elapsedSeconds, period);
    const angle = angleAtCycleElapsed(elapsedSeconds, period) - Math.PI / 2;
    const vectors = circleVectors(angle, 96);
    const point = { x: 140 + vectors.position.x, y: 140 + vectors.position.y };
    body.setAttribute("cx", point.x);
    body.setAttribute("cy", point.y);
    radius.setAttribute("x2", point.x);
    radius.setAttribute("y2", point.y);
    panel.querySelector("[data-period-value]").textContent = formatNumber(period, 1);
    panel.querySelector("[data-frequency-value]").textContent = formatNumber(frequencyFromPeriod(period));
    panel.querySelector("[data-frequency-elapsed]").textContent = formatElapsed(currentElapsed);
  }

  function tick(time) {
    if (!running) return;
    const elapsed = last ? (time - last) / 1000 : 0;
    last = time;
    elapsedSeconds += elapsed;
    update();
    frame = requestAnimationFrame(tick);
  }

  function start() {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      status.textContent = "Bewegung ist wegen der Einstellung für reduzierte Bewegung angehalten.";
      return;
    }
    if (!running) {
      running = true;
      last = 0;
      status.textContent = "Bewegung läuft. Die Zeitanzeige beginnt nach jeder Runde wieder bei 0.";
      frame = requestAnimationFrame(tick);
    }
  }

  function pause(message = "Bewegung pausiert.") {
    running = false;
    cancelAnimationFrame(frame);
    status.textContent = message;
  }

  panel.querySelector('[data-frequency-action="start"]').addEventListener("click", start);
  panel.querySelector('[data-frequency-action="pause"]').addEventListener("click", () => pause());
  panel.querySelector('[data-frequency-action="reset"]').addEventListener("click", () => { pause("Bewegung zurückgesetzt."); elapsedSeconds = 0; update(); });
  input.addEventListener("input", () => { pause("Umlaufdauer geändert. Starte die Bewegung erneut."); elapsedSeconds = 0; update(); });
  document.addEventListener("visibilitychange", () => { if (document.hidden && running) pause("Bewegung pausiert, weil die Seite nicht sichtbar ist."); });
  new MutationObserver(() => { if (panel.hidden && running) pause("Bewegung pausiert, weil der Reiter gewechselt wurde."); }).observe(panel, { attributes: true, attributeFilter: ["hidden"] });
  update();
}

function centripetalFeedback(result) {
  const fragment = document.createDocumentFragment();
  const text = document.createElement("p");
  const strong = document.createElement("strong"); strong.textContent = "nach innen";
  if (result.context === "server-error") { text.append("Zum fachlichen Vergleich: Die Zentripetalkraft beginnt am Körper und zeigt ", strong, " zum Kreismittelpunkt. Deine eingegebene Antwort bleibt erhalten."); } else if (result.status === "korrekt") { text.append("Richtig: Der Geschwindigkeitsvektor verläuft tangential zur Kreisbahn. Die Zentripetalkraft beginnt am Körper und zeigt ", strong, " zum Kreismittelpunkt."); } else if (result.points > 0) { text.append("Teilweise richtig. Beachte die oben genannten fehlenden Aspekte. Die Zentripetalkraft beginnt am Körper und zeigt ", strong, " zum Kreismittelpunkt."); } else { text.append("Noch nicht richtig. Der Geschwindigkeitspfeil beginnt am Körper und liegt tangential. Die Zentripetalkraft zeigt ", strong, " zum Kreismittelpunkt."); }
  fragment.append(text); return fragment;
}

function setupCentripetalCloze() {
  const terms = [{ key: "force", text: "Kraft" }, { key: "motion", text: "Kreisbewegung" }, { key: "inside", text: "innen" }, { key: "outside", text: "außen" }, { key: "magnitude", text: "der Betrag der Geschwindigkeit" }, { key: "direction-a", text: "die Richtung der Geschwindigkeit" }, { key: "direction-b", text: "die Richtung der Geschwindigkeit" }];
  const expected = ["force", "magnitude", "direction", "motion", "inside", "direction"];
  const parts = ["Wirkt eine ", " auf einen Körper, ändert sich ", " und/oder ", ". Bei einer ", " wirkt die Zentripetalkraft nach ", ", denn es ändert sich ständig ", "."];
  const target = document.getElementById("centripetal-cloze"); const choices = new Array(expected.length).fill("");
  let order = [...terms].sort(() => Math.random() - 0.5);
  const textOf = (key) => terms.find((term) => term.key === key)?.text || "";
  const dragSelectors = { dropSelector: "#centripetal-cloze .cloze-gap", bankSelector: "#centripetal-cloze .cloze-term-bank" };
  let picked = null; // { value, from } mit from = Lückenindex oder -1 (Wortspeicher)
  const bank = document.createElement("div"); bank.className = "cloze-term-bank"; bank.setAttribute("aria-label", "Wortspeicher");
  const sentence = document.createElement("p"); sentence.className = "cloze-sentence";

  function place(value, from, gapIndex) {
    if (from >= 0) choices[from] = "";
    if (gapIndex >= 0) {
      const previous = choices[gapIndex];
      choices[gapIndex] = value;
      if (from >= 0 && previous) choices[from] = previous; // Tausch zwischen zwei Lücken
    }
    picked = null;
    document.getElementById("centripetal-cloze-feedback").hidden = true;
    document.getElementById("notebook-reminder").hidden = true;
    render();
    taskProgress.save();
  }

  const render = () => {
    bank.replaceChildren(...order.filter((term) => !choices.includes(term.key)).map((term) => {
      const token = document.createElement("button");
      token.type = "button";
      token.className = "cloze-token";
      token.textContent = term.text;
      const isPicked = picked?.value === term.key && picked.from === -1;
      token.setAttribute("aria-pressed", String(isPicked));
      token.classList.toggle("is-picked", isPicked);
      enableTokenDrag(token, { ...dragSelectors, getLabel: () => term.text, onDrop: (gap) => { if (gap) place(term.key, -1, Number(gap.dataset.index)); else render(); } });
      token.addEventListener("click", () => {
        if (wasDragged(token)) return;
        picked = isPicked ? null : { value: term.key, from: -1 };
        render();
        if (picked) (sentence.querySelector(".cloze-gap:not(.is-filled)") || sentence.querySelector(".cloze-gap"))?.focus();
      });
      return token;
    }));

    sentence.replaceChildren();
    parts.forEach((part, index) => {
      sentence.append(document.createTextNode(part));
      if (index >= expected.length) return;
      const value = choices[index];
      const gap = document.createElement("button");
      gap.type = "button";
      gap.className = "cloze-gap";
      gap.dataset.index = String(index);
      gap.textContent = value ? textOf(value) : " ";
      gap.classList.toggle("is-filled", Boolean(value));
      // Kein Abstand vor einem Satzzeichen, das direkt an die Lücke anschließt.
      gap.classList.toggle("is-attached", /^[.,:;!?]/.test(parts[index + 1] || ""));
      gap.classList.toggle("is-picked", picked?.from === index);
      gap.setAttribute("aria-label", `Lücke ${index + 1}: ${value ? textOf(value) : "leer"}`);
      enableTokenDrag(gap, {
        ...dragSelectors,
        getLabel: () => textOf(choices[index]),
        onDrop: (dropGap, onBank) => {
          if (dropGap && Number(dropGap.dataset.index) !== index) place(value, index, Number(dropGap.dataset.index));
          else if (onBank) place(value, index, -1);
          else render();
        },
      });
      gap.addEventListener("click", () => {
        if (wasDragged(gap)) return;
        if (picked && picked.from !== index) { place(picked.value, picked.from, index); sentence.querySelector(`[data-index="${index}"]`)?.focus(); return; }
        if (picked && picked.from === index) { place(value, index, -1); return; }
        if (value) { picked = { value, from: index }; render(); sentence.querySelector(`[data-index="${index}"]`)?.focus(); }
      });
      sentence.append(gap);
    });
  };

  target.append(bank, sentence);
  render();
  taskProgress.registerPart("centripetal-cloze", () => ({ choices: [...choices], bankOrder: order.map((term) => term.key) }), (saved) => {
    const keys = new Set(terms.map((term) => term.key));
    if (!saved || !Array.isArray(saved.choices) || saved.choices.length !== choices.length
      || saved.choices.some((key) => key !== "" && !keys.has(key))) return;
    const used = saved.choices.filter(Boolean);
    if (new Set(used).size !== used.length || !Array.isArray(saved.bankOrder)
      || saved.bankOrder.length !== terms.length || saved.bankOrder.some((key) => !keys.has(key))
      || new Set(saved.bankOrder).size !== terms.length) return;
    choices.splice(0, choices.length, ...saved.choices);
    order = saved.bankOrder.map((key) => terms.find((term) => term.key === key));
    picked = null;
    render();
  });
  const category = (key) => key.startsWith("direction") ? "direction" : key;
  document.getElementById("check-centripetal-cloze").addEventListener("click", () => { const correct = choices.filter((choice, index) => category(choice) === expected[index]).length; if (correct === expected.length) { setFeedback("centripetal-cloze-feedback", "success", "Korrekt: Der Merksatz ist vollständig und fachlich richtig."); document.getElementById("notebook-reminder").hidden = false; } else { document.getElementById("notebook-reminder").hidden = true; if (correct) setFeedback("centripetal-cloze-feedback", "partial", `${correct} von ${expected.length} Lücken stimmen. Prüfe besonders, was sich bei einer Kreisbewegung ändert.`); else setFeedback("centripetal-cloze-feedback", "error", "Noch nicht korrekt. Setze zunächst die Karten in die Lücken ein."); } });
  document.getElementById("reset-centripetal-cloze").addEventListener("click", () => { choices.fill(""); picked = null; document.getElementById("centripetal-cloze-feedback").hidden = true; document.getElementById("notebook-reminder").hidden = true; render(); sentence.querySelector(".cloze-gap")?.focus(); });
}

function renderQuizQuestion(target, item, index) {
  const fieldset = document.createElement("fieldset"); fieldset.className = "physics-quiz-question"; const legend = document.createElement("legend"); appendPhysicsText(legend, `${index + 1}. ${item.question}${item.correct.length > 1 ? " (mehrere Antworten)" : ""}`); const options = document.createElement("div"); options.className = "quiz-options";
  item.options.forEach(([value, labelText]) => { const label = document.createElement("label"); label.className = "quiz-option"; const input = document.createElement("input"); input.type = "checkbox"; input.value = value; label.append(input, physicsTextSpan(labelText, "quiz-option-text")); options.append(label); });
  const check = document.createElement("button"); check.type = "button"; check.className = "physics-primary-button direct-check-button"; check.textContent = "Antwort prüfen"; const feedback = document.createElement("p"); feedback.className = "physics-feedback"; feedback.hidden = true; feedback.setAttribute("role", "status"); feedback.setAttribute("aria-live", "polite"); check.addEventListener("click", () => { const selected = [...fieldset.querySelectorAll("input:checked")].map((input) => input.value); const hits = selected.filter((value) => item.correct.includes(value)); const extras = selected.filter((value) => !item.correct.includes(value)); const exact = hits.length === item.correct.length && extras.length === 0; if (exact) setFeedback(feedback, "success", "Korrekt: " + item.feedback); else if (hits.length && !extras.length) setFeedback(feedback, "partial", "Teilweise korrekt: Es fehlt noch mindestens eine richtige Aussage. " + item.hint); else setFeedback(feedback, "error", "Noch nicht korrekt. " + item.hint); }); fieldset.append(legend, options, check, feedback); target.append(fieldset);
}

function setupAngleQuiz() {
  const item = {
    question: "Welche Aussagen zur Winkelgeschwindigkeit ω sind richtig?",
    correct: ["time-larger", "angle-smaller"],
    options: [
      ["time-larger", "Je kleiner das Zeitintervall Δt bei gleichbleibendem Winkel Δφ, desto **größer** die Winkelgeschwindigkeit."],
      ["time-smaller", "Je kleiner das Zeitintervall Δt bei gleichbleibendem Winkel Δφ, desto **kleiner** die Winkelgeschwindigkeit."],
      ["angle-larger", "Je kleiner der Winkel Δφ bei gleichbleibendem Zeitintervall Δt, desto **größer** die Winkelgeschwindigkeit."],
      ["angle-smaller", "Je kleiner der Winkel Δφ bei gleichbleibendem Zeitintervall Δt, desto **kleiner** die Winkelgeschwindigkeit."],
    ],
    feedback: "Wird derselbe Winkel in kürzerer Zeit überstrichen, dreht sich die Verbindungslinie schneller. Ein kleinerer Winkel in derselben Zeit bedeutet eine langsamere Drehung.",
    hint: "Verändere in der Animation nur Δt oder nur Δφ und beobachte jeweils den Wert von ω.",
  };
  renderQuizQuestion(document.getElementById("angle-quiz"), item, 0);
}

function setupQuiz() {
  const items = [
    { question: "Was beschreibt der Drehwinkel Δφ?", correct: ["angle"], options: [["angle", "Die Weiterdrehung der Verbindungslinie zwischen Zentrum und Körper."], ["time", "Die Zeit für eine beliebige Strecke."], ["radius", "Die Länge der Kreisbahn."]], feedback: "Δφ wird im Bogenmaß angegeben.", hint: "Denk an die Verbindungslinie vom Zentrum zum Körper." },
    { question: "Welche Aussagen zur Winkelgeschwindigkeit sind richtig?", correct: ["formula", "unit"], options: [["formula", "ω ergibt sich aus Drehwinkel geteilt durch Zeitintervall."], ["unit", "Eine Einheit von ω ist {{rad/s}}."], ["radius", "Bei größerem Radius ist ω immer größer."]], feedback: "Winkelgeschwindigkeit beschreibt die Drehung pro Zeit.", hint: "Vergleiche Drehwinkel, Zeit und Einheit." },
    { question: "Welche Aussagen zur Bahngeschwindigkeit {{v_B}} sind richtig?", correct: ["omega", "radius"], options: [["omega", "Bei gleichem Radius vergrößert eine größere Winkelgeschwindigkeit {{v_B}}."], ["radius", "Bei gleicher Winkelgeschwindigkeit vergrößert ein größerer Radius {{v_B}}."], ["inverse", "{{v_B}} wird kleiner, wenn ω oder r größer werden."]], feedback: "Es gilt {{v_B}} = ω · r.", hint: "Nutze die Multiplikation von ω und r." },
    { question: "Welche Aussagen zu Frequenz f und Umlaufdauer T sind richtig?", correct: ["inverse", "unit"], options: [["inverse", "f und T sind Kehrwerte."], ["unit", "Die Einheit der Frequenz ist Hertz."], ["same", "Eine größere Umlaufdauer bedeutet eine größere Frequenz."]], feedback: "Eine kurze Umlaufdauer bedeutet viele Umdrehungen pro Zeit.", hint: "Vergleiche den Kehrwert von T für kleine und große T." },
    { question: "Wie ist der Geschwindigkeitsvektor bei einer Kreisbewegung eingezeichnet?", correct: ["tangent"], options: [["tangent", "Er beginnt am Körper und verläuft tangential zur Kreisbahn."], ["center", "Er beginnt am Zentrum und zeigt zum Körper."], ["inward", "Er beginnt am Körper und zeigt immer nach innen."]], feedback: "Der Geschwindigkeitspfeil berührt die Kreisbahn am Körper.", hint: "Die Bewegungsrichtung folgt der Tangente." },
    { question: "Welche Aussagen zur Zentripetalkraft sind richtig?", correct: ["origin", "inward", "function"], options: [["origin", "Der Kraftpfeil beginnt am Körper."], ["inward", "Er zeigt zum Kreismittelpunkt nach innen."], ["function", "Er sorgt für die ständige Änderung der Geschwindigkeitsrichtung."], ["outward", "Er zeigt vom Zentrum nach außen."]], feedback: "Die resultierende Kraft hält den Körper auf der Kreisbahn.", hint: "Achte auf Startpunkt, Richtung und Wirkung der Kraft." },
    { question: "Was geschieht beim Wegfall der Zentripetalkraft?", correct: ["straight"], options: [["straight", "Der Körper bewegt sich tangential geradlinig weiter."], ["circle", "Der Körper bleibt ohne Kraft auf derselben Kreisbahn."], ["center", "Der Körper fliegt sofort zum Mittelpunkt."]], feedback: "Ohne resultierende Kraft bleibt die momentane Bewegungsrichtung erhalten.", hint: "Nutze den Trägheitssatz." }
  ];
  const target = document.getElementById("circle-quiz"); items.forEach((item, index) => renderQuizQuestion(target, item, index));
}

setupPhysicsStepTabs();
setupAngleSimulation();
setupAngleQuiz();
setupSpeedSimulation();
setupFormulaBuilder({ id: "formula-angle", expected: ["ω", "Δφ", "Δt"], equation: "ω gleich Δφ durch Δt", rememberId: "angle-remember" });
setupFormulaBuilder({ id: "formula-speed", expected: ["vB", "ω", "r"], equation: "v mit Index B gleich Omega mal r", rememberId: "speed-remember" });
setupFormulaBuilder({ id: "formula-frequency", expected: ["f", "1", "T"], equation: "f gleich 1 durch T", rememberId: "frequency-remember" });
setupFrequency();
setupPhysicsSemanticTask({ answerId: "centripetal-answer", buttonId: "check-centripetal", feedbackId: "centripetal-feedback", countId: "centripetal-count", taskId: "ph11-kreisbewegungen-zentripetalkraft-beschreibung", serverUrl: SCRIPT_SERVER_URL, feedbackBuilder: centripetalFeedback, minimumLength: 8, fallbackMaxPoints: 5 });
setupCentripetalCloze();
setupQuiz();
taskProgress.restore();
